import { createHash } from 'node:crypto';

import { TensorEvaluatorConnectorError } from './connector.mjs';

const RESOURCE_LAYOUT_CONTRACT = 'cuda-mcgs.tensor-evaluator-resource-layout/0.1.0';
const RESOURCE_BINDING_CONTRACT = 'cuda-mcgs.tensor-evaluator-resource-binding/0.1.0';
const PROGRAM_BINDING_CONTRACT = 'cuda-mcgs.tensor-evaluator-program-binding/0.1.0';
const EVALUATOR_SCHEMA = 'cuda-mcgs.evaluator-profile/0.2.0';
const RESOURCE_SCHEMA = 'cuda-mcgs.resource-profile/0.2.0';
const CONNECTOR_CONTRACT = 'cuda-mcgs.tensor-evaluator-connector/0.1.0';
const LAYOUT_SCHEMA = 'cuda-mcgs.tensor-evaluator-resource-layout/0.1.0';
const LAYOUT_VERSION = '0.1.0';
const LAYOUT_CONTRACT_ID = 'integration.cuda-js-tensor-evaluator-resource-layout';
const DTYPE_WIDTH = Object.freeze({ u32: 4, i32: 4, u64: 8, f32: 4, f64: 8, f16: 2, bf16: 2 });
const IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
const NAMESPACED_ID = /^[a-z][a-z0-9-]*(?:\.[a-z0-9][a-z0-9-]*)+$/;
const DECIMAL = /^(?:0|[1-9][0-9]*)$/;
const HEX64 = /^[0-9a-f]{64}$/;

function freeze(value) {
  if (value === null || typeof value !== 'object') return value;
  return Object.freeze(Array.isArray(value)
    ? value.map(freeze)
    : Object.fromEntries(Object.entries(value).map(([key, child]) => [key, freeze(child)])));
}

function fail(code, message, details = {}) {
  throw new TensorEvaluatorConnectorError(code, message, details);
}

function object(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_INPUT', `${label} must be an object`);
  return value;
}

function exactKeys(value, expected, code, label) {
  object(value, label);
  const actual = Object.keys(value).sort();
  const wanted = [...expected].sort();
  if (actual.length !== wanted.length || actual.some((key, index) => key !== wanted[index])) fail(code, `${label} fields must be exactly ${wanted.join(', ')}`);
}

function identifier(value, label) {
  if (typeof value !== 'string' || !IDENTIFIER.test(value)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_PARAMETER', `${label} must be a Device-JS identifier`);
  return value;
}

function namespacedId(value, label) {
  if (typeof value !== 'string' || !NAMESPACED_ID.test(value)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ID', `${label} must be a namespaced id`);
  return value;
}

function decimal(value, label) {
  if (typeof value !== 'string' || !DECIMAL.test(value)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_RANGE', `${label} must be a canonical decimal uint string`);
  return BigInt(value);
}

function positiveSafe(value, label) {
  if (!Number.isSafeInteger(value) || value <= 0) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_RANGE', `${label} must be a positive safe integer`);
  return value;
}

function width(dtype, label) {
  const value = DTYPE_WIDTH[dtype];
  if (!value) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_DTYPE', `${label} uses unsupported dtype ${dtype}`);
  return BigInt(value);
}

function sha256(value) {
  return createHash('sha256').update(value, 'utf8').digest('hex');
}

function canonical(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
}

function canonicalIdentity(value) {
  return { algorithm: 'sha256', sha256: sha256(canonical(value)) };
}

function contentIdentity(value, label) {
  object(value, label);
  if (value.algorithm !== 'sha256' || typeof value.sha256 !== 'string' || !HEX64.test(value.sha256)) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY', `${label} must be a sha256 content identity`);
  }
  return { algorithm: 'sha256', sha256: value.sha256 };
}

function accessSet(value, label) {
  if (value === 'read') return ['read'];
  if (value === 'write') return ['write'];
  if (value === 'read-write') return ['read', 'write'];
  fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ACCESS', `${label} access is invalid`);
}


function connector(value) {
  object(value, 'Tensor evaluator connector');
  if (value.kind !== 'cuda-mcgs-tensor-evaluator-connector' || value.contract !== CONNECTOR_CONTRACT
      || !value.tensor || !Number.isSafeInteger(value.requestCapacity) || value.requestCapacity <= 0
      || !Array.isArray(value.parameters) || !value.deviceImportIdentity) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CONNECTOR', 'connector is not the admitted public Tensor evaluator connector shape');
  }
  return value;
}

function programBinding(value) {
  object(value, 'Tensor evaluator program binding');
  if (value.kind !== 'cuda-mcgs-tensor-evaluator-program-binding' || value.contract !== PROGRAM_BINDING_CONTRACT
      || typeof value.id !== 'string' || typeof value.ownerProfile !== 'string' || !value.sourceUnit
      || !Array.isArray(value.functions) || value.functions.length === 0
      || !Array.isArray(value.resourceRequirements) || !Array.isArray(value.tensorBindings)) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_PROGRAM', 'program binding is not the admitted Tensor evaluator program-binding shape');
  }
  return value;
}

function evaluatorProfileResult(value, ownerProfile) {
  object(value, 'evaluator profile result');
  const normalized = object(value.normalized, 'normalized evaluator profile');
  const identity = contentIdentity(value.identity, 'evaluator profile identity');
  if (normalized.schema !== EVALUATOR_SCHEMA || normalized.status !== 'accepted' || normalized.contract?.id !== 'SPEC-0009'
      || normalized.id !== ownerProfile || normalized.execution?.deviceOwned !== true || normalized.execution?.hostProgress !== 'none') {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_EVALUATOR', 'normalized evaluator profile does not match the program-binding owner');
  }
  return { normalized, identity };
}

function runtimeDescriptor(entry) {
  object(entry, 'runtime resource requirement');
  identifier(entry.parameterName, `${entry.id ?? '<unknown>'} parameterName`);
  if (typeof entry.id !== 'string' || !entry.id.startsWith('runtime.') || !Number.isSafeInteger(entry.byteLength) || entry.byteLength <= 0
      || !Number.isSafeInteger(entry.elementCount) || entry.elementCount <= 0) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_LOGICAL', `${entry.id ?? '<unknown>'} runtime resource requirement is invalid`);
  }
  const dtypeWidth = width(entry.dtype, entry.id);
  if (BigInt(entry.elementCount) * dtypeWidth !== BigInt(entry.byteLength)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_LOGICAL', `${entry.id} element layout differs from byteLength`);
  let requiredAccess = accessSet(entry.access, entry.id);
  if (entry.id === 'runtime.control32') requiredAccess = ['read', 'write', 'atomic', 'publish'];
  if (entry.id === 'runtime.control64') requiredAccess = ['read', 'write'];
  return {
    parameterName: entry.parameterName,
    logicalId: entry.id,
    logicalKind: 'runtime-resource',
    sourceOwner: 'cuda-mcgs-evaluator-runtime',
    dtype: entry.dtype,
    elementCount: BigInt(entry.elementCount),
    byteLength: BigInt(entry.byteLength),
    alignment: dtypeWidth,
    requiredAccess,
    initialization: entry.initialization,
  };
}

function tensorDescriptor(entry, connectorParameter) {
  object(entry, 'Tensor binding');
  identifier(entry.parameterName, `${entry.parameterName ?? '<unknown>'} parameterName`);
  if (!Number.isSafeInteger(entry.byteLength) || entry.byteLength <= 0) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_LOGICAL', `${entry.parameterName} Tensor binding byteLength is invalid`);
  const dtypeWidth = width(entry.dtype, entry.parameterName);
  object(connectorParameter, `${entry.parameterName} connector parameter`);
  if (connectorParameter.parameterName !== entry.parameterName || connectorParameter.role !== entry.role || connectorParameter.dtype !== entry.dtype
      || connectorParameter.access !== entry.access || connectorParameter.itemVarying !== entry.itemVarying || connectorParameter.byteLength !== entry.byteLength) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CONNECTOR', `${entry.parameterName} Tensor binding differs from the admitted connector ABI`);
  }
  if (BigInt(entry.byteLength) % dtypeWidth !== 0n) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_LOGICAL', `${entry.parameterName} Tensor binding byteLength is not dtype aligned`);
  const alignment = connectorParameter.alignmentBytes === undefined ? Number(dtypeWidth) : positiveSafe(connectorParameter.alignmentBytes, `${entry.parameterName} alignmentBytes`);
  if (BigInt(alignment) % dtypeWidth !== 0n) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ALIGNMENT', `${entry.parameterName} Tensor alignment is not dtype aligned`);
  return {
    parameterName: entry.parameterName,
    logicalId: `tensor.${entry.parameterName}`,
    logicalKind: 'tensor-abi-resource',
    sourceOwner: 'cuda-js-tensor-callable',
    dtype: entry.dtype,
    elementCount: BigInt(entry.byteLength) / dtypeWidth,
    byteLength: BigInt(entry.byteLength),
    alignment: BigInt(alignment),
    requiredAccess: accessSet(entry.access, entry.parameterName),
    initialization: entry.initialization,
  };
}

function logicalDescriptors(binding, admittedConnector) {
  const connectorByParameter = new Map(admittedConnector.parameters.filter(({ role }) => role !== 'item-index').map((entry) => [entry.parameterName, entry]));
  if (connectorByParameter.size !== binding.tensorBindings.length || binding.tensorBindings.some(({ parameterName }) => !connectorByParameter.has(parameterName))) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CONNECTOR', 'program Tensor bindings do not exactly cover the admitted connector ABI');
  }
  const descriptors = [...binding.resourceRequirements.map(runtimeDescriptor), ...binding.tensorBindings.map((entry) => tensorDescriptor(entry, connectorByParameter.get(entry.parameterName)))];
  const byParameter = new Map();
  for (const descriptor of descriptors) {
    if (byParameter.has(descriptor.parameterName)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_PARAMETER', `logical parameter ${descriptor.parameterName} is duplicated`);
    byParameter.set(descriptor.parameterName, descriptor);
  }
  const pointerTypes = new Map();
  for (const fn of binding.functions) for (const parameter of fn.parameters ?? []) {
    if (typeof parameter.type !== 'string' || !parameter.type.startsWith('ptr<')) continue;
    const match = /^ptr<([A-Za-z0-9_-]+)>$/.exec(parameter.type);
    if (!match) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_PARAMETER', `${fn.name}.${parameter.name} pointer type is invalid`);
    const prior = pointerTypes.get(parameter.name);
    if (prior && prior !== match[1]) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_PARAMETER', `${parameter.name} has inconsistent pointer dtypes`);
    pointerTypes.set(parameter.name, match[1]);
  }
  if (pointerTypes.size !== byParameter.size || [...pointerTypes.keys()].some((name) => !byParameter.has(name))) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_COVERAGE', 'logical resources do not exactly cover evaluator program pointer parameters');
  }
  for (const [name, dtype] of pointerTypes) if (byParameter.get(name).dtype !== dtype) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_DTYPE', `${name} logical dtype differs from program pointer type`);
  return [...byParameter.values()].sort((left, right) => left.parameterName.localeCompare(right.parameterName));
}

function layoutContract() {
  return {
    kind: 'namespaced',
    id: LAYOUT_CONTRACT_ID,
    version: LAYOUT_VERSION,
    schema: LAYOUT_SCHEMA,
    sha256: sha256(`contract:${RESOURCE_LAYOUT_CONTRACT}`),
  };
}

function layoutSchemaReference() {
  return { id: LAYOUT_SCHEMA, version: LAYOUT_VERSION, sha256: sha256(`schema:${LAYOUT_SCHEMA}`) };
}

function programResourceFingerprint(binding, admittedConnector) {
  return canonicalIdentity({
    ownerProfile: binding.ownerProfile,
    bindingId: binding.id,
    sourceIdentity: binding.sourceUnit.sourceIdentity,
    resourceRequirements: binding.resourceRequirements,
    tensorBindings: binding.tensorBindings,
    connector: {
      tensor: admittedConnector.tensor,
      requestCapacity: admittedConnector.requestCapacity,
      parameters: admittedConnector.parameters,
      deviceImportIdentity: admittedConnector.deviceImportIdentity,
    },
  });
}

export function createTensorEvaluatorResourceLayout(connectorInput, programBindingInput, evaluatorProfileResultInput, options = {}) {
  const admittedConnector = connector(connectorInput);
  const binding = programBinding(programBindingInput);
  const evaluatorResult = evaluatorProfileResult(evaluatorProfileResultInput, binding.ownerProfile);
  exactKeys(options, ['id'], 'TENSOR_EVALUATOR_RESOURCE_BINDING_OPTIONS', 'resource-layout options');
  const id = namespacedId(options.id, 'resource-layout id');
  const descriptors = logicalDescriptors(binding, admittedConnector);
  const resources = descriptors.map((descriptor, index) => {
    const byteLength = descriptor.byteLength.toString();
    return {
      id: `${id}.resource-${String(index + 1).padStart(2, '0')}`,
      parameterName: descriptor.parameterName,
      logicalId: descriptor.logicalId,
      logicalKind: descriptor.logicalKind,
      sourceOwner: descriptor.sourceOwner,
      dtype: descriptor.dtype,
      elementCount: descriptor.elementCount.toString(),
      byteLength,
      alignment: descriptor.alignment.toString(),
      access: [...descriptor.requiredAccess],
      memorySpaces: ['device-search'],
      initialization: descriptor.initialization,
      unit: 'bytes',
      minimum: byteLength,
      maximum: byteLength,
      scope: 'per-engine',
      pressureStatus: 'tensor-evaluator-resource-capacity',
    };
  });
  const normalized = {
    schema: LAYOUT_SCHEMA,
    status: 'accepted',
    contract: layoutContract(),
    id,
    version: LAYOUT_VERSION,
    ownerProfile: evaluatorResult.normalized.id,
    evaluatorProfileIdentity: { ...evaluatorResult.identity },
    programResourceIdentity: programResourceFingerprint(binding, admittedConnector),
    resources,
    ownership: {
      semanticEvaluatorResources: 'not-relabelled',
      representationResources: 'integration-owned-derived-from-runtime-and-public-tensor-abi',
      resourcePlanPolicy: 'resource-owned',
      providerMechanism: 'cuda-js-owned',
    },
  };
  const identity = canonicalIdentity(normalized);
  const schemaReference = layoutSchemaReference();
  return freeze({ normalized, identity, schemaReference, schemaSha: schemaReference.sha256 });
}

function resourceLayoutResult(value, binding, admittedConnector) {
  object(value, 'Tensor evaluator resource-layout result');
  const normalized = object(value.normalized, 'normalized Tensor evaluator resource layout');
  const identity = contentIdentity(value.identity, 'resource-layout identity');
  const schemaReference = object(value.schemaReference, 'resource-layout schema reference');
  if (normalized.schema !== LAYOUT_SCHEMA || normalized.status !== 'accepted' || normalized.contract?.id !== LAYOUT_CONTRACT_ID
      || normalized.id !== value.normalized.id || normalized.ownerProfile !== binding.ownerProfile || !Array.isArray(normalized.resources)
      || schemaReference.id !== LAYOUT_SCHEMA || schemaReference.version !== LAYOUT_VERSION || !HEX64.test(schemaReference.sha256)) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_LAYOUT', 'resource-layout result is invalid');
  }
  if (canonicalIdentity(normalized).sha256 !== identity.sha256) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY', 'resource-layout identity does not match its normalized content');
  if (normalized.programResourceIdentity?.sha256 !== programResourceFingerprint(binding, admittedConnector).sha256) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY', 'resource layout differs from the exact Tensor evaluator program resources');
  return { normalized, identity, schemaReference };
}

function sameContract(left, right) {
  return left?.kind === right.kind && left?.id === right.id && left?.version === right.version && left?.schema === right.schema && left?.sha256 === right.sha256;
}

function resourceProfileResult(value, layoutResult) {
  object(value, 'Resource profile result');
  const normalized = object(value.normalized, 'normalized Resource profile');
  const identity = contentIdentity(value.identity, 'Resource profile identity');
  if (normalized.schema !== RESOURCE_SCHEMA || normalized.status !== 'accepted' || normalized.contract?.id !== 'SPEC-0011'
      || !Array.isArray(normalized.contributors) || !Array.isArray(normalized.classes) || !Array.isArray(normalized.partitions)
      || !Array.isArray(normalized.pools) || !Array.isArray(normalized.providerRequirements)) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_RESOURCE', 'normalized Resource profile is invalid');
  }
  const layout = layoutResult.normalized;
  const contributors = normalized.contributors.filter(({ contract, profile }) => contract?.id === LAYOUT_CONTRACT_ID && profile?.id === layout.id);
  if (contributors.length !== 1) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_RESOURCE', 'Resource plan does not contain exactly one selected Tensor evaluator resource-layout contributor');
  const contributor = contributors[0];
  if (!sameContract(contributor.contract, layout.contract)
      || contributor.profile?.schema?.id !== layoutResult.schemaReference.id
      || contributor.profile?.schema?.version !== layoutResult.schemaReference.version
      || contributor.profile?.schema?.sha256 !== layoutResult.schemaReference.sha256
      || contributor.profile?.identity?.algorithm !== 'sha256'
      || contributor.profile.identity.sha256 !== layoutResult.identity.sha256) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY', 'Resource layout contributor differs from the exact adapter resource-layout identity');
  }
  return { normalized, identity, contributor };
}

function exactResourceChain(resource, contributorId, layoutResource) {
  const classes = resource.classes.filter((entry) => entry.contributor === contributorId && entry.sourceResource === layoutResource.id);
  if (classes.length !== 1) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN', `${layoutResource.id} does not map to exactly one Resource class`);
  const resourceClass = classes[0];
  const partitions = resource.partitions.filter(({ class: classId }) => classId === resourceClass.id);
  if (partitions.length !== 1) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN', `${resourceClass.id} does not map to exactly one partition`);
  const partition = partitions[0];
  if (partition.alias?.kind !== 'none') fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ALIAS', `${partition.id} first realization cannot alias Tensor evaluator layout storage`);
  const pool = resource.pools.find(({ id }) => id === partition.pool);
  if (!pool) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN', `${partition.id} has no Resource pool`);
  const providers = resource.providerRequirements.filter(({ pool: poolId }) => poolId === pool.id);
  if (providers.length !== 1) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN', `${pool.id} does not map to exactly one provider requirement`);
  return { resourceClass, partition, pool, provider: providers[0] };
}

function alignment(value, label) {
  const result = decimal(value, label);
  if (result <= 0n) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ALIGNMENT', `${label} must be positive`);
  return result;
}

function supportsAlignment(actual, required) {
  return actual >= required && actual % required === 0n;
}

function assertPhysicalEnvelope(layoutResource, chain) {
  const byteLength = decimal(layoutResource.byteLength, `${layoutResource.id} byteLength`);
  const requiredAlignment = alignment(layoutResource.alignment, `${layoutResource.id} alignment`);
  const maximum = decimal(layoutResource.maximum, `${layoutResource.id} maximum`);
  const classMaximum = decimal(chain.resourceClass.formula?.maximumUnits, `${chain.resourceClass.id} maximumUnits`);
  const partitionCapacity = decimal(chain.partition.capacity, `${chain.partition.id} capacity`);
  const partitionOffset = decimal(chain.partition.offset, `${chain.partition.id} offset`);
  const poolCapacity = decimal(chain.pool.capacity, `${chain.pool.id} capacity`);
  const providerCapacity = decimal(chain.provider.capacity, `${chain.provider.id} capacity`);
  if (layoutResource.unit !== 'bytes' || maximum !== byteLength || chain.resourceClass.unit !== 'bytes' || chain.pool.unit !== 'bytes' || chain.provider.unit !== 'bytes'
      || classMaximum !== maximum || partitionCapacity < maximum || providerCapacity !== poolCapacity) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN', `${layoutResource.id} Resource chain does not preserve the exact derived byte extent`);
  }
  for (const holder of [chain.resourceClass, chain.pool, chain.provider]) {
    if (!holder.memorySpaces?.includes('device-search')) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_MEMORY', `${layoutResource.parameterName} is not backed by device-search storage`);
    for (const required of layoutResource.access) if (!holder.access?.includes(required)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ACCESS', `${layoutResource.parameterName} requires ${required} access absent from its Resource chain`);
  }
  const classAlignment = alignment(chain.resourceClass.alignment, `${chain.resourceClass.id} alignment`);
  const partitionAlignment = alignment(chain.partition.alignment, `${chain.partition.id} alignment`);
  const poolAlignment = alignment(chain.pool.alignment, `${chain.pool.id} alignment`);
  const providerAlignment = alignment(chain.provider.alignment, `${chain.provider.id} alignment`);
  if (![classAlignment, partitionAlignment, poolAlignment, providerAlignment].every((value) => supportsAlignment(value, requiredAlignment))) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ALIGNMENT', `${layoutResource.parameterName} Resource chain cannot guarantee its required alignment`);
  }
  if (partitionOffset % requiredAlignment !== 0n || partitionOffset + byteLength > poolCapacity) {
    fail('TENSOR_EVALUATOR_RESOURCE_BINDING_ALIGNMENT', `${layoutResource.parameterName} provider-relative view is misaligned or out of range`);
  }
  return { byteLength, partitionOffset };
}

function overlaps(left, right) {
  return left.pool === right.pool && left.byteOffset < right.byteOffset + right.byteLength && right.byteOffset < left.byteOffset + left.byteLength;
}

export function createTensorEvaluatorResourceBinding(connectorInput, programBindingInput, resourceLayoutResultInput, resourceProfileResultInput, options = {}) {
  const admittedConnector = connector(connectorInput);
  const binding = programBinding(programBindingInput);
  exactKeys(options, [], 'TENSOR_EVALUATOR_RESOURCE_BINDING_OPTIONS', 'resource-binding options');
  const layoutResult = resourceLayoutResult(resourceLayoutResultInput, binding, admittedConnector);
  const { normalized: resource, identity: resourceIdentity, contributor } = resourceProfileResult(resourceProfileResultInput, layoutResult);
  const layout = layoutResult.normalized;
  const allocations = [];
  for (const layoutResource of layout.resources) {
    const chain = exactResourceChain(resource, contributor.id, layoutResource);
    const { byteLength, partitionOffset } = assertPhysicalEnvelope(layoutResource, chain);
    allocations.push({
      parameterName: layoutResource.parameterName,
      logicalId: layoutResource.logicalId,
      logicalKind: layoutResource.logicalKind,
      sourceOwner: layoutResource.sourceOwner,
      layoutResource: layoutResource.id,
      resourceClass: chain.resourceClass.id,
      partition: chain.partition.id,
      pool: chain.pool.id,
      providerRequirement: chain.provider.id,
      access: layoutResource.access.includes('write') ? (layoutResource.access.includes('read') ? 'read-write' : 'write') : 'read',
      requiredAccess: [...layoutResource.access],
      view: { dtype: layoutResource.dtype, byteOffset: partitionOffset.toString(), elementCount: layoutResource.elementCount },
      byteLength: byteLength.toString(),
      alignment: layoutResource.alignment,
      initialization: layoutResource.initialization,
    });
  }
  if (allocations.length !== layout.resources.length) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_COVERAGE', 'Resource plan does not exactly cover the Tensor evaluator layout');
  for (let leftIndex = 0; leftIndex < allocations.length; leftIndex += 1) for (let rightIndex = leftIndex + 1; rightIndex < allocations.length; rightIndex += 1) {
    const left = { pool: allocations[leftIndex].pool, byteOffset: BigInt(allocations[leftIndex].view.byteOffset), byteLength: BigInt(allocations[leftIndex].byteLength) };
    const right = { pool: allocations[rightIndex].pool, byteOffset: BigInt(allocations[rightIndex].view.byteOffset), byteLength: BigInt(allocations[rightIndex].byteLength) };
    if (overlaps(left, right)) fail('TENSOR_EVALUATOR_RESOURCE_BINDING_OVERLAP', `${allocations[leftIndex].parameterName} and ${allocations[rightIndex].parameterName} overlap in ${left.pool}`);
  }
  const providers = [...new Set(allocations.map(({ providerRequirement }) => providerRequirement))].sort();
  return freeze({
    kind: 'cuda-mcgs-tensor-evaluator-resource-binding',
    contract: RESOURCE_BINDING_CONTRACT,
    ownerProfile: binding.ownerProfile,
    resourceLayout: { id: layout.id, identity: { ...layoutResult.identity } },
    resourcePlan: { id: resource.id, identity: { ...resourceIdentity } },
    layoutContributor: contributor.id,
    allocations,
    usesProviderRequirements: providers,
    ownership: {
      semanticEvaluatorResources: 'unchanged',
      representationLayout: layout.id,
      providerRequirements: 'resource-owned-references-only',
      placement: 'resource-plan-owned',
    },
    claimLimits: [
      'exact-adapter-layout-and-resource-plan-identities-bound',
      'byte-extents-derived-from-runtime-and-public-tensor-abi',
      'semantic-evaluator-resource-classes-not-relabelled',
      'resource-plan-policy-and-placement-not-created-or-mutated',
      'provider-requirements-referenced-not-owned',
      'progress-runtime-entry-and-service-order-not-included',
      'no-native-or-provider-qualification',
    ],
  });
}

export const tensorEvaluatorResourceBindingConstants = Object.freeze({
  layoutContract: RESOURCE_LAYOUT_CONTRACT,
  bindingContract: RESOURCE_BINDING_CONTRACT,
  programBindingContract: PROGRAM_BINDING_CONTRACT,
  layoutSchema: LAYOUT_SCHEMA,
  layoutContractId: LAYOUT_CONTRACT_ID,
  evaluatorSchema: EVALUATOR_SCHEMA,
  resourceSchema: RESOURCE_SCHEMA,
  dtypeWidth: DTYPE_WIDTH,
});
