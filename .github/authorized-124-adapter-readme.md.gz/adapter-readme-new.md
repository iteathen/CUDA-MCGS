# CUDA-JS-Tensor evaluator connector

`integration.cuda-js-tensor-evaluator` is the optional CUDA-MCGS adapter for a public `cuda-js-tensor` `TensorDeviceProgram`.

The admission connector remains stateless: it validates the public Tensor callable, finite item/request capacity, parameter roles, workspace total and opaque Device-JS library identity, then returns a fresh owner-produced `DeviceJsImport` only while that identity still matches the admitted Tensor program.

The adapter also exposes an evaluator-owned **device runtime contribution**. That contribution generates restricted Device-JS plus finite MCGS-owned request-slot, batch, result and staging layouts for admission, partial/full batching, Tensor item execution, stale-safe scatter, publication, cancellation, retry and recycle. It is a contribution to a Search Program, not a host runtime and not a scheduler. `Progress` still owns when and where ready evaluator work is serviced after ignition.

The **program binding** keeps this runtime inside existing generic Search Compiler ownership rather than adding Tensor vocabulary to Composer. `bindTensorEvaluatorProfileProgram()` makes the exact generated Device-JS source digest and the runtime-selected public CUDA-JS contract references part of the selected SPEC-0009 evaluator `programContribution` before generic normalization. `createTensorEvaluatorProgramBinding()` then projects that normalized evaluator owner into Program-Package-compatible source/function/`DeviceJsImport` fragments with explicit one-to-one work-class mapping and structural deletion ownership.

The **Resource seam is representation-preserving, not a byte-size escape hatch**. `createTensorEvaluatorResourceLayout()` derives an immutable, identity-bearing resource-layout contribution from the exact MCGS runtime buffers and the admitted public Tensor callable ABI. Runtime control/staging byte extents remain derived from the evaluator runtime; Tensor input/output/workspace byte extents and workspace alignment remain derived from the public Tensor connector. The layout is a separate integration-owned representation contribution. It does not relabel evaluator semantic request/queue/batch counts as bytes or workspace.

Resource remains the physical-plan authority. A selected Resource plan may include the exact layout contribution and choose its pools, partitions, offsets and provider requirements. `createTensorEvaluatorResourceBinding()` then verifies the exact layout-profile identity, exact Resource-plan identity, complete one-to-one source-resource chain, byte extent, alignment, device-search memory eligibility, access/publication envelope, non-aliasing first realization and provider coverage. It returns provider-relative typed views; it never creates or mutates the Resource plan and never chooses an allocator.

Ownership stays split deliberately:

- CUDA-JS-Tensor owns Tensor mathematics, TensorProgram/TensorPlan meaning, item-axis addressing, the public item callable ABI and Tensor workspace requirements.
- CUDA-MCGS evaluator semantics own request/batch/result incarnation, finite evaluator state, stale rejection, cancellation/retry and result publication.
- The selected evaluator profile/Search Program owns semantic encoding of domain/model inputs. The generic Tensor adapter exposes per-request encoded-input staging but does not invent domain/model encoding.
- The Tensor integration owns only the concrete representation layout needed to connect those evaluator transitions to the admitted public Tensor ABI; semantic evaluator resource classes remain unchanged.
- Resource owns physical pools, partitions, offsets, provider requirements, accounting, pressure/exhaustion and cleanup closure.
- Progress owns service order/topology and partial-batch opportunity. The first runtime contribution permits a one-item partial batch and at most one active Tensor batch without using host timing or polling.
- CUDA-JS owns Device-JS validation/lowering, device release/acquire helpers, linking, allocation/operation mechanics and native execution.

Every post-batch item work record must carry the captured incarnation token `{ itemIndex, slot, slotGeneration, requestGeneration, batchGeneration }`. Generated execute/scatter/publish/retry functions revalidate that token before touching current lane state. A delayed work item from an older lane incarnation returns stale without invoking Tensor or mutating the reused request/result lane.

Publication uses a single CAS from `inflight` to evaluator-owned `publishing`, followed by a release publication of the terminal slot state. The contribution explicitly selects the public CUDA-JS Device-JS and device release/acquire contracts; it does not maintain a helper spelling catalog or infer lower requirements from helper text. The program binding requires the full public schema references for those selected contracts; it does not manufacture contract hashes.

All MCGS-owned control, request-staging and result-staging buffers require explicit zero initialization before ignition. Shared Tensor inputs remain explicit external pre-ignition inputs. The CUDA-JS runtime adapter still submits one Search Program operation; this adapter does not add a host gather/launch/poll/relaunch loop.

This remains an incremental #124 slice, not full #124 acceptance. Exact evaluator program ownership and the adapter-to-Resource representation binding are explicit. Progress runtime-entry/service-order integration, complete cross-owner terminal resource closure and native/provider/hardware qualification remain open. Portable source/state/program/resource-binding evidence is not native/provider/hardware evidence.

Focused qualification:

```sh
node scripts/run-cuda-js-tensor-evaluator.mjs
node conformance/cuda-js-tensor-evaluator/package.mjs
```
