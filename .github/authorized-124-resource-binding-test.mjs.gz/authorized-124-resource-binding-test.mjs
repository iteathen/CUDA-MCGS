import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

import {
  TensorEvaluatorConnectorError,
  bindTensorEvaluatorProfileProgram,
  createTensorEvaluatorConnector,
  createTensorEvaluatorProgramBinding,
  createTensorEvaluatorResourceBinding,
  createTensorEvaluatorResourceLayout,
  createTensorEvaluatorRuntimeContribution,
  tensorEvaluatorResourceBindingConstants,
} from '../../adapters/evaluators/cuda-js-tensor/index.mjs';

function sha256(value) {
  return createHash('sha256').update(value, 'utf8').digest('hex');
}

function schemaReference(id) {
  const version = id.split('/').at(-1);
  return { id, version, sha256: sha256(`schema:${id}`) };
}

function fakeTensorDeviceProgram(workspaceAlignment = 16) {
  const parameters = [
    { parameterIndex: 0, parameterName: 'itemIndex', role: 'item-index', type: 'u32', dtype: 'u32', access: 'read', itemVarying: false },
    { parameterIndex: 1, parameterName: 'features', role: 'input', type: 'ptr<f32>', dtype: 'f32', access: 'read', itemVarying: true, byteLength: 16 },
    { parameterIndex: 2, parameterName: 'weights', role: 'input', type: 'ptr<f32>', dtype: 'f32', access: 'read', itemVarying: false, byteLength: 16 },
    { parameterIndex: 3, parameterName: 'scores', role: 'output', type: 'ptr<f32>', dtype: 'f32', access: 'write', itemVarying: true, byteLength: 16 },
    { parameterIndex: 4, parameterName: 'scratch', role: 'workspace', type: 'ptr<f32>', dtype: 'f32', access: 'read-write', itemVarying: true, byteLength: 16 },
  ];
  const fn = { name: 'tensorRunItem', parameters: parameters.map(({ parameterName: name, type }) => ({ name, type })), returns: 'u32' };
  const library = {
    schemaVersion: 1,
    contract: 'SPEC-0013-v1+SPEC-0022-atomic-observation-v1+SPEC-0022-device-publication-v1+SPEC-0014-publication-mailbox-v1+SPEC-0030-dense-numeric-v1+SPEC-0028-device-library-v1',
    sha256: '1'.repeat(64),
    format: 'lto-ir',
    architecture: 'compute_90',
    exports: [{ name: 'tensorRunItem', symbol: 'tensorRunItem', parameters: fn.parameters, returns: 'u32' }],
    artifact: { format: 'lto-ir', bytes: new Uint8Array([1]), byteLength: 1, sha256: '2'.repeat(64), architecture: 'compute_90', producer: { profile: 'fixture', nvrtcVersion: 'fixture' } },
  };
  return {
    kind: 'tensor-device-program', contract: 'SPEC-0009-item-parallel-device-tensor-program-v1', itemCapacity: 2, outputFormat: 'lto-ir', parameters,
    inputs: [
      { ...parameters[1], name: 'features', valueId: 'value.features', elementCount: 4 },
      { ...parameters[2], name: 'weights', valueId: 'value.weights', elementCount: 4 },
    ],
    outputs: [{ ...parameters[3], name: 'scores', valueId: 'value.scores', perItemElements: 2, elementCount: 4 }],
    workspace: [{ ...parameters[4], perItemElements: 2, elementCount: 4, alignmentBytes: workspaceAlignment }],
    totalWorkspaceBytes: 16,
    function: fn,
    compatibilityIdentity: `tensor-resource-layout-fixture-a${workspaceAlignment}`,
    library,
    importAs(alias) { return Object.freeze({ library, name: 'tensorRunItem', as: alias }); },
  };
}

const workClasses = Object.freeze({
  encode: 'evaluator.tensor.work-encode', admit: 'evaluator.tensor.work-admit', batch: 'evaluator.tensor.work-batch',
  execute: 'evaluator.tensor.work-execute', scatter: 'evaluator.tensor.work-scatter', publish: 'evaluator.tensor.work-publish',
});

function evaluatorProfileInput() {
  return {
    schema: 'cuda-mcgs.evaluator-profile/0.2.0', representation: 'cuda-mcgs.search-ir/0.2.0', status: 'accepted',
    contract: { kind: 'catalog', id: 'SPEC-0009', specificationIdentity: 'CUDA-MCGS-SPEC-0009@0.2.0', sha256: '3'.repeat(64) },
    id: 'evaluator.tensor', version: '0.1.0',
    request: { maxActive: '3' }, batching: { minimumReadyItems: '1', maximumItems: '2' },
    execution: { deviceOwned: true, hostProgress: 'none', workClasses: Object.values(workClasses) },
    statuses: [
      'evaluator-request-capacity', 'evaluator-input-stale', 'evaluator-cancelled', 'evaluator-internal-failure',
      'evaluator-generation-exhausted', 'evaluator-batch-pending',
    ].map((code) => ({ code })),
    resources: [
      { id: 'evaluator.tensor.resource-request', class: 'request', unit: 'records', minimum: '1', maximum: '3', alignment: '8', scope: 'per-engine', pressureStatus: 'evaluator-request-capacity' },
      { id: 'evaluator.tensor.resource-queue', class: 'queue', unit: 'slots', minimum: '1', maximum: '3', alignment: '8', scope: 'per-engine', pressureStatus: 'evaluator-request-capacity' },
      { id: 'evaluator.tensor.resource-batch', class: 'batch', unit: 'records', minimum: '1', maximum: '2', alignment: '8', scope: 'per-engine', pressureStatus: 'evaluator-batch-pending' },
      { id: 'evaluator.tensor.resource-input', class: 'input', unit: 'bytes', minimum: '1', maximum: '1024', alignment: '8', scope: 'per-engine', pressureStatus: 'invalid-evaluator-input' },
      { id: 'evaluator.tensor.resource-result', class: 'result', unit: 'bytes', minimum: '1', maximum: '1024', alignment: '8', scope: 'per-engine', pressureStatus: 'evaluator-output-invalid' },
      { id: 'evaluator.tensor.resource-workspace', class: 'workspace', unit: 'bytes', minimum: '1', maximum: '1024', alignment: '8', scope: 'per-engine', pressureStatus: 'evaluator-workspace-capacity' },
    ],
    programContribution: {
      kind: 'device-program', language: 'restricted-device-js', sourceIdentity: { algorithm: 'sha256', sha256: '0'.repeat(64) }, inputs: [],
      provenance: { origin: 'first-party', revision: '4'.repeat(40), license: 'Apache-2.0', review: schemaReference('cuda-mcgs.tensor-resource-layout-review/0.1.0') },
    },
  };
}

function identity(value) {
  return { algorithm: 'sha256', sha256: sha256(JSON.stringify(value)) };
}

function align(value, alignment) {
  const remainder = value % alignment;
  return remainder === 0 ? value : value + alignment - remainder;
}

function resourceProfile(layoutResult, evaluatorResult) {
  const layout = layoutResult.normalized;
  const layoutOwner = 'owner.tensor-resource-layout';
  const evaluatorOwner = 'owner.evaluator.tensor';
  const maxAlignment = Math.max(...layout.resources.map(({ alignment }) => Number(alignment)));
  let cursor = 0;
  const classes = [];
  const partitions = [];
  for (let index = 0; index < layout.resources.length; index += 1) {
    const entry = layout.resources[index];
    const alignmentValue = Number(entry.alignment);
    cursor = align(cursor, alignmentValue);
    const classId = `resource.layout.class-${index + 1}`;
    const partitionId = `resource.layout.partition-${index + 1}`;
    classes.push({
      id: classId, contributor: layoutOwner, sourceResource: entry.id, unit: 'bytes', minimumUnits: entry.minimum,
      formula: { maximumUnits: entry.maximum }, alignment: entry.alignment, memorySpaces: ['device-search'], access: [...entry.access], scope: 'per-engine',
    });
    partitions.push({
      id: partitionId, class: classId, pool: 'resource.layout.pool', offset: String(cursor), capacity: entry.maximum,
      alignment: entry.alignment, cleanupOrder: String(index + 1), alias: { kind: 'none' },
    });
    cursor += Number(entry.maximum);
  }
  cursor = align(cursor, maxAlignment);
  const layoutAccess = [...new Set(layout.resources.flatMap(({ access }) => access))].sort();
  const pool = {
    id: 'resource.layout.pool', unit: 'bytes', capacity: String(cursor), alignment: String(maxAlignment),
    memorySpaces: ['device-search'], access: layoutAccess, lifetime: 'engine', providerRequirement: 'resource.layout.provider',
  };
  const provider = {
    id: pool.providerRequirement, pool: pool.id, unit: 'bytes', capacity: pool.capacity, alignment: pool.alignment,
    memorySpaces: [...pool.memorySpaces], access: [...pool.access], lifecycle: schemaReference('cuda-mcgs.tensor-resource-layout-provider-lifecycle/0.1.0'),
    opaqueResult: identity('resource.layout.provider'),
  };
  const semanticClass = {
    id: 'resource.semantic.request-class', contributor: evaluatorOwner, sourceResource: 'evaluator.tensor.resource-request', unit: 'records', minimumUnits: '1',
    formula: { maximumUnits: '3' }, alignment: '8', memorySpaces: ['device-search'], access: ['read', 'write', 'atomic'], scope: 'per-engine',
  };
  const semanticPool = { id: 'resource.semantic.request-pool', unit: 'records', capacity: '3', alignment: '8', memorySpaces: ['device-search'], access: ['read', 'write', 'atomic'], lifetime: 'engine', providerRequirement: 'resource.semantic.request-provider' };
  const normalized = {
    schema: 'cuda-mcgs.resource-profile/0.2.0', representation: 'cuda-mcgs.search-ir/0.2.0', status: 'accepted', contract: { id: 'SPEC-0011' }, id: 'resource.tensor-layout-fixture',
    contributors: [
      {
        id: layoutOwner,
        contract: { ...layout.contract },
        profile: { id: layout.id, schema: { ...layoutResult.schemaReference }, identity: { ...layoutResult.identity } },
      },
      {
        id: evaluatorOwner, contract: { id: 'SPEC-0009' },
        profile: { id: evaluatorResult.normalized.id, schema: { id: evaluatorResult.normalized.schema }, identity: { ...evaluatorResult.identity } },
      },
    ],
    classes: [...classes, semanticClass],
    partitions: [...partitions, { id: 'resource.semantic.request-partition', class: semanticClass.id, pool: semanticPool.id, offset: '0', capacity: '3', alignment: '8', cleanupOrder: '99', alias: { kind: 'none' } }],
    pools: [pool, semanticPool],
    providerRequirements: [provider, { id: semanticPool.providerRequirement, pool: semanticPool.id, unit: 'records', capacity: '3', alignment: '8', memorySpaces: ['device-search'], access: ['read', 'write', 'atomic'], lifecycle: schemaReference('cuda-mcgs.semantic-request-provider-lifecycle/0.1.0'), opaqueResult: identity('resource.semantic.request-provider') }],
  };
  return { normalized, identity: identity(normalized) };
}

const connector = createTensorEvaluatorConnector(fakeTensorDeviceProgram(), { requestCapacity: 3 });
const runtime = createTensorEvaluatorRuntimeContribution(connector);
const requirements = runtime.requiredCudaJsContracts.map(schemaReference);
const boundEvaluator = bindTensorEvaluatorProfileProgram(evaluatorProfileInput(), runtime, { publicRequirements: requirements });
const program = createTensorEvaluatorProgramBinding(runtime, boundEvaluator, { id: 'evaluator.tensor.program-binding', workClasses });
const evaluatorResult = { normalized: boundEvaluator, identity: identity(boundEvaluator) };
const layout = createTensorEvaluatorResourceLayout(connector, program, evaluatorResult, { id: 'integration.tensor-evaluator-layout' });
const resources = resourceProfile(layout, evaluatorResult);
const binding = createTensorEvaluatorResourceBinding(connector, program, layout, resources);

assert.equal(layout.normalized.contract.id, tensorEvaluatorResourceBindingConstants.layoutContractId);
assert.equal(layout.normalized.schema, tensorEvaluatorResourceBindingConstants.layoutSchema);
assert.equal(layout.normalized.ownerProfile, boundEvaluator.id);
assert.deepEqual(layout.normalized.evaluatorProfileIdentity, evaluatorResult.identity);
assert.equal(layout.normalized.resources.length, program.resourceRequirements.length + program.tensorBindings.length);
assert.equal(layout.normalized.resources.find(({ parameterName }) => parameterName === 'mcgsEvalControl32').sourceOwner, 'cuda-mcgs-evaluator-runtime');
assert.equal(layout.normalized.resources.find(({ parameterName }) => parameterName === 'scratch').sourceOwner, 'cuda-js-tensor-callable');
assert.equal(layout.normalized.resources.find(({ parameterName }) => parameterName === 'scratch').alignment, '16', 'public Tensor workspace alignment must survive into Resource layout');
assert.deepEqual(layout.normalized.resources.find(({ parameterName }) => parameterName === 'features').access, ['read', 'write'], 'item-varying Tensor input becomes runtime read-write staging without changing the public Tensor ABI');
assert.deepEqual(layout.normalized.resources.find(({ parameterName }) => parameterName === 'weights').access, ['read'], 'shared Tensor input preserves public read-only access');
assert.deepEqual(layout.normalized.resources.find(({ parameterName }) => parameterName === 'scores').access, ['read', 'write'], 'Tensor output becomes runtime read-write staging for execute-plus-scatter');
assert.equal(layout.normalized.resources.some(({ logicalId }) => logicalId === 'evaluator.tensor.resource-workspace'), false, 'representation layout must not relabel persistent control state as evaluator workspace');
assert.equal(layout.normalized.ownership.semanticEvaluatorResources, 'not-relabelled');
assert(Object.isFrozen(layout));
assert(Object.isFrozen(layout.normalized.resources[0]));

assert.equal(binding.contract, tensorEvaluatorResourceBindingConstants.bindingContract);
assert.equal(binding.ownerProfile, boundEvaluator.id);
assert.deepEqual(binding.resourceLayout, { id: layout.normalized.id, identity: layout.identity });
assert.deepEqual(binding.resourcePlan, { id: resources.normalized.id, identity: resources.identity });
assert.equal(binding.allocations.length, layout.normalized.resources.length);
assert(binding.allocations.every(({ resourceClass }) => resources.normalized.classes.find(({ id }) => id === resourceClass)?.contributor === 'owner.tensor-resource-layout'));
assert(binding.allocations.every(({ providerRequirement }) => providerRequirement === 'resource.layout.provider'));
assert(!binding.usesProviderRequirements.includes('resource.semantic.request-provider'));
assert.equal(binding.ownership.semanticEvaluatorResources, 'unchanged');
assert.equal(binding.ownership.placement, 'resource-plan-owned');
assert(binding.claimLimits.includes('semantic-evaluator-resource-classes-not-relabelled'));
assert(binding.claimLimits.includes('byte-extents-derived-from-runtime-and-public-tensor-abi'));
const control32 = binding.allocations.find(({ parameterName }) => parameterName === 'mcgsEvalControl32');
assert(control32.requiredAccess.includes('atomic'));
assert(control32.requiredAccess.includes('publish'));
const scratch = binding.allocations.find(({ parameterName }) => parameterName === 'scratch');
assert.equal(scratch.alignment, '16');
assert.equal(BigInt(scratch.view.byteOffset) % 16n, 0n);
assert(Object.isFrozen(binding));
assert(Object.isFrozen(binding.allocations[0]));

const identityDrift = structuredClone(resources);
identityDrift.normalized.contributors.find(({ id }) => id === 'owner.tensor-resource-layout').profile.identity.sha256 = 'f'.repeat(64);
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, identityDrift),
  (error) => error instanceof TensorEvaluatorConnectorError && error.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY',
);

const crossOwner = structuredClone(resources);
crossOwner.normalized.classes.find(({ sourceResource }) => sourceResource === layout.normalized.resources[0].id).contributor = 'owner.evaluator.tensor';
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, crossOwner),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_CHAIN',
);

const accessDrift = structuredClone(resources);
accessDrift.normalized.providerRequirements.find(({ id }) => id === 'resource.layout.provider').access = ['read', 'write', 'atomic'];
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, accessDrift),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_ACCESS',
);

const alignmentDrift = structuredClone(resources);
alignmentDrift.normalized.providerRequirements.find(({ id }) => id === 'resource.layout.provider').alignment = '8';
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, alignmentDrift),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_ALIGNMENT',
);

const overlap = structuredClone(resources);
const layoutPartitions = overlap.normalized.partitions.filter(({ id }) => id.startsWith('resource.layout.partition-'));
layoutPartitions[1].offset = layoutPartitions[0].offset;
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, overlap),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_OVERLAP',
);

const aliased = structuredClone(resources);
aliased.normalized.partitions.find(({ id }) => id.startsWith('resource.layout.partition-')).alias = { kind: 'proven' };
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, layout, aliased),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_ALIAS',
);

const connectorDrift = createTensorEvaluatorConnector(fakeTensorDeviceProgram(8), { requestCapacity: 3 });
assert.throws(
  () => createTensorEvaluatorResourceBinding(connectorDrift, program, layout, resources),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY' || error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_CONNECTOR',
);

const mutatedLayout = structuredClone(layout);
mutatedLayout.normalized.resources[0].byteLength = String(Number(mutatedLayout.normalized.resources[0].byteLength) + 4);
assert.throws(
  () => createTensorEvaluatorResourceBinding(connector, program, mutatedLayout, resources),
  (error) => error?.code === 'TENSOR_EVALUATOR_RESOURCE_BINDING_IDENTITY',
);

console.log(JSON.stringify({
  schema: 'cuda-mcgs.tensor-evaluator-resource-binding-portable-evidence/0.1.0',
  status: 'pass',
  layoutResources: layout.normalized.resources.length,
  allocations: binding.allocations.length,
  providers: binding.usesProviderRequirements.length,
  cases: [
    'runtime-and-public-tensor-abi-own-byte-extents',
    'public-tensor-workspace-alignment-preserved',
    'semantic-evaluator-resources-not-relabelled',
    'resource-layout-profile-identity-bound',
    'resource-plan-selects-layout-contributor',
    'resource-plan-owns-placement-and-provider-chain',
    'control-publication-access-preserved',
    'layout-resource-coverage-exact',
    'identity-cross-owner-access-alignment-overlap-alias-drift-fail-closed',
    'connector-layout-drift-fail-closed',
    'deep-freeze',
  ],
  claimLimits: [
    'adapter-resource-layout-and-binding-only',
    'does-not-create-or-mutate-resource-plan',
    'does-not-relabel-semantic-evaluator-count-resources',
    'does-not-select-progress-service-order',
    'does-not-call-cuda-js-allocation',
    'no-native-or-provider-qualification',
  ],
}));
